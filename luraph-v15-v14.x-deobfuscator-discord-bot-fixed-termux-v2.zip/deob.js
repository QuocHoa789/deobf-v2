'use strict';

// Bridge used by bot/index.js. It selects the bundled v14 frontend or v15
// frontend and forwards all CLI arguments unchanged.
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const DEOB_DIR = path.join(ROOT, 'Deobfuscator', 'deobf');
const V14_CLI = path.join(DEOB_DIR, 'cli.py');
const V15_CLI = path.join(DEOB_DIR, 'deob.py');
const argv = process.argv.slice(2);

function readInput() {
  const input = argv.find(a => !a.startsWith('-') && !argv[argv.indexOf(a) - 1]?.match(/^-(o|--output|--engine)$/));
  if (!input || !fs.existsSync(input)) return '';
  try { return fs.readFileSync(input, 'utf8').slice(0, 4096); } catch { return ''; }
}

function chooseScript() {
  const source = readInput();
  const m = source.match(/This file was protected using Luraph Obfuscator v(\d+)(?:\.(\d+))?/i);
  if (m && m[1] === '15') return V15_CLI;
  if (m && m[1] === '14') return V14_CLI;
  // Headerless --detect: the general v15 detector can still recognize v15.
  if (argv.includes('--detect')) return V15_CLI;

  // Headerless files: let the v14 frontend try its known v14 shapes first.
  // If it cannot identify the file, the v15 frontend can still handle its
  // headerless LPH/VM shape when called explicitly by the user.
  return V14_CLI;
}

const chosen = chooseScript();
const candidates = process.env.PYTHON_BIN ? [process.env.PYTHON_BIN] : ['python3', 'python'];
let last = null;

for (const python of candidates) {
  const r = spawnSync(python, [chosen, ...argv], {
    cwd: DEOB_DIR,
    stdio: 'inherit',
    env: { ...process.env, PYTHONUNBUFFERED: '1' }
  });
  if (r.error && r.error.code === 'ENOENT') { last = r.error; continue; }
  if (r.error) {
    console.error(`Failed to start Python (${python}): ${r.error.message}`);
    process.exit(1);
  }
  process.exit(r.status === null ? 1 : r.status);
}

console.error('Python was not found. Install it with: pkg install python -y');
if (last) console.error(last.message);
process.exit(1);
