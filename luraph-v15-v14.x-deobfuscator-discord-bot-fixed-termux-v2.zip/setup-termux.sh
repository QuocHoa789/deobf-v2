#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js/npm is missing. Run: pkg install nodejs-lts -y"
  exit 1
fi
if ! command -v python >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
  echo "Python is missing. Run: pkg install python -y"
  exit 1
fi
if [ -f "$HOME/luau/CMakeLists.txt" ] && [ -d "$HOME/luau/build" ] && [ ! -x "$HOME/luau/build/luau-ast" ]; then
  echo "[+] Building Luau.Ast.CLI..."
  cmake --build "$HOME/luau/build" --target Luau.Ast.CLI -j2
fi
if [ ! -x "$HOME/luau/build/luau-ast" ] && [ ! -x "$HOME/luau/cmake/luau-ast" ] && [ ! -x "$PREFIX/bin/luau-ast" ]; then
  echo "[!] luau-ast is still unavailable."
  exit 1
fi
cd bot
npm install
cd ..
chmod +x start-bot.sh Deobfuscator/deobf/bin/luau-ast Deobfuscator/deobf/luau-ast
printf '\nSetup OK. Run: ./start-bot.sh\n'
