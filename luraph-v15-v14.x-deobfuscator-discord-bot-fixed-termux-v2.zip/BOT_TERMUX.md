# Luraph V14.x / V15 Discord Bot — Termux

## One-time setup

```bash
pkg update -y
pkg install nodejs-lts python -y
cd /path/to/project
cd bot
npm install
```

The project already contains the Python deobfuscation engines. `deob.js` is the Node wrapper used by `bot/index.js`.

## Start

From the project root:

```bash
./start-bot.sh
```

Or:

```bash
cd bot
node index.js
```

The bot asks:

```text
Enter Discord bot token:
```

Paste the token and press Enter.

## Commands

- `.help` — help
- `.d` + `.lua/.luau/.txt` attachment — automatic deobfuscation
- `.token` — show available player tokens
- Owner: `.t @player` — issue a player token
- `/deobf` — slash-command deobfuscation
- `/detect` — detect the obfuscator

The bundled registry includes Luraph v14.7, v14.8, v14.9 and v15 engines.

The default Discord attachment limit for this bot is 13 MB; override with `MAX_FILE_MB`, for example:

```bash
MAX_FILE_MB=20 node bot/index.js
```

Enable **Message Content Intent** in the Discord Developer Portal for prefix commands such as `.d`.
