# Luraph V14.x / V15 Discord Bot — Termux

## First run

```bash
pkg update -y
pkg install nodejs-lts python -y
cd /path/to/luraph-v15-v14.x-deobfuscator-discord-bot
cd bot
npm install
cd ..
./start-bot.sh
```

The bot asks `Enter Discord bot token:`. Paste the token and press Enter.

## Later runs

```bash
cd /path/to/luraph-v15-v14.x-deobfuscator-discord-bot
./start-bot.sh
```

## Commands

- `.d` + attached `.lua/.luau/.txt` — deobfuscate
- `.token` — show available player tokens
- `.t @player` — Owner grants a player token
- `.help` — help
- `/deobf` — slash-command deobfuscation
- `/detect` — detect engine

The Node bot calls the bundled `deob.js` bridge. V14.7/14.8/14.9 are routed to `Deobfuscator/deobf/cli.py`; V15 is routed to `Deobfuscator/deobf/deob.py`.

Default attachment limit is 13 MB. Override with `MAX_FILE_MB=20` if needed.
