#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"

# On Termux, build the native AST CLI automatically if the user's Luau source
# tree/build directory already exists (the user previously built Luau here).
AST="$HOME/luau/build/luau-ast"
if [ ! -x "$AST" ] && [ -f "$HOME/luau/CMakeLists.txt" ] && [ -d "$HOME/luau/build" ]; then
  echo "[+] luau-ast not found; building native Termux Luau.Ast.CLI..."
  cmake --build "$HOME/luau/build" --target Luau.Ast.CLI -j2
fi

if [ ! -x "$AST" ] && [ ! -x "$HOME/luau/cmake/luau-ast" ] && [ ! -x "$PREFIX/bin/luau-ast" ]; then
  echo "[!] Native luau-ast is missing."
  echo "    Build it with:"
  echo "    cd ~/luau && cmake --build build --target Luau.Ast.CLI -j2"
  exit 1
fi

cd bot
npm install
exec node index.js
