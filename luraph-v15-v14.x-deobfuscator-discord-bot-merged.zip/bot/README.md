# Discord bot wrapper

Bot Discord gọi engine deobfuscator có sẵn trong repository thông qua `deob.js`.

## Hệ thống player token

- `DISCORD_TOKEN` chỉ dùng để bot đăng nhập Discord. Đây **không phải** player token.
- Mỗi player token là **1 lượt dùng `.d`**.
- Mỗi lần Owner dùng `.t @player`, player được cấp thêm **1 token mới**.
- Khi player dùng `.d` và job bắt đầu, **1 token được đánh dấu đã dùng**. Token đã dùng không xuất hiện lại trong `.token`.
- Nếu `.d` không thể chạy vì thiếu file, sai phần mở rộng, hoặc bot đang bận, token chưa bị trừ.
- Nếu job deobf đã bắt đầu nhưng deobf thất bại, token vẫn được tính là đã dùng vì đó là một lượt xử lý.
- Hai Discord ID `1188496254464970872` và `1486380909736366120` là **Owner**, có quyền `.t @player` và được bypass giới hạn token: `.d` không bao giờ tiêu hao token của Owner.

## Commands

### Người dùng bình thường

- `.help` — xem danh sách lệnh cơ bản (chỉ hiện `.d` và `.token`).
- `.d` + file `.lua/.luau/.txt` — deobf full mode; cần ít nhất 1 player token.
- `.token` — xem các player token còn chưa dùng và số lượt còn lại.

### Owner

- `.help` — xem toàn bộ command prefix và slash command hiện có.
- `.t @player` — cấp **1 player token mới** cho player được mention.
- `.d` + file — deobf; Owner vô hạn token.
- `.token` — hiển thị trạng thái Owner vô hạn token.

### Slash commands hiện có

- `/deobf file:<attachment> mode:full` — deobf, dùng chung cơ chế tiêu hao player token.
- `/deobf file:<attachment> mode:trace` — behavior trace, cũng dùng chung cơ chế tiêu hao player token.
- `/detect file:<attachment>` — detect obfuscator.

Player token được lưu runtime trong `bot/data/player_tokens.json`; file này đã được thêm vào `.gitignore`.

Bot nhận file tối đa 8 MB theo mặc định; đặt `MAX_FILE_MB` để thay đổi.
Bot xử lý một deob job tại một thời điểm để tránh quá tải Termux.
