#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/Deobfuscator/deobf${PYTHONPATH:+:$PYTHONPATH}"
: "${DISCORD_BOT_TOKEN:?Set DISCORD_BOT_TOKEN first}"
python discord_bot.py
