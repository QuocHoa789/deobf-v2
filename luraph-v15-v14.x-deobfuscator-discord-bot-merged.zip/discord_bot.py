import asyncio
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import discord
from discord.ext import commands

BASE_DIR = Path(__file__).resolve().parent
CLI = BASE_DIR / "Deobfuscator" / "deobf" / "cli.py"
MAX_INPUT_BYTES = int(os.getenv("DEOBF_MAX_BYTES", str(8 * 1024 * 1024)))
TIMEOUT = int(os.getenv("DEOBF_TIMEOUT", "3600"))
OWNER_IDS = {int(x) for x in os.getenv("BOT_OWNER_IDS", "").split(",") if x.strip().isdigit()}

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=".", intents=intents, help_command=None)


def safe_name(name: str) -> str:
    name = Path(name).name
    name = re.sub(r"[^A-Za-z0-9_.-]", "_", name)
    return name or "input.txt"


def run_deobfuscator(src: Path, out: Path, engine: str | None) -> tuple[int, str]:
    cmd = [sys.executable, str(CLI), str(src), "-o", str(out)]
    if engine:
        cmd += ["--engine", engine]
    proc = subprocess.run(
        cmd,
        cwd=str(CLI.parent),
        capture_output=True,
        text=True,
        timeout=TIMEOUT,
    )
    log = (proc.stdout + "\n" + proc.stderr).strip()
    return proc.returncode, log


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (id={bot.user.id})")


@bot.command(name="help")
async def help_cmd(ctx: commands.Context):
    await ctx.reply(
        "**Deobfuscator Bot**\n"
        "`.d` + đính kèm file `.lua`, `.luau` hoặc `.txt` để deobfuscate.\n"
        "Ví dụ: gửi file kèm `.d`\n"
        "Có thể ép engine: `.d 14.7`, `.d 14.8` hoặc `.d 14.9`."
    )


@bot.command(name="d")
@commands.cooldown(1, 10, commands.BucketType.user)
async def deobf_cmd(ctx: commands.Context, engine: str = "auto"):
    if not ctx.message.attachments:
        await ctx.reply("Hãy đính kèm file `.lua`, `.luau` hoặc `.txt` rồi dùng `.d`.")
        return

    attachment = ctx.message.attachments[0]
    name = safe_name(attachment.filename)
    if not name.lower().endswith((".lua", ".luau", ".txt")):
        await ctx.reply("File không được hỗ trợ. Chỉ nhận `.lua`, `.luau` hoặc `.txt`.")
        return

    if attachment.size > MAX_INPUT_BYTES:
        await ctx.reply(f"File quá lớn. Giới hạn hiện tại: {MAX_INPUT_BYTES // (1024 * 1024)} MB.")
        return

    engine = engine.lower().removeprefix("v")
    if engine not in {"auto", "14.7", "14.8", "14.9"}:
        await ctx.reply("Engine không hợp lệ. Dùng `auto`, `14.7`, `14.8` hoặc `14.9`.")
        return

    work = Path(tempfile.mkdtemp(prefix="discord_deobf_"))
    src = work / name
    out = work / "deobfuscated.lua"
    status = await ctx.reply("⏳ Đã nhận file, đang deobfuscate...")

    try:
        await attachment.save(src)
        selected = None if engine == "auto" else engine
        code, log = await asyncio.to_thread(run_deobfuscator, src, out, selected)

        if code != 0 or not out.is_file():
            tail = log[-1800:] if log else "Không có log lỗi."
            await status.edit(content=f"❌ Deobf thất bại.\n```text\n{tail}\n```")
            return

        await status.edit(content="✅ Deobf xong.")
        await ctx.send(
            file=discord.File(out, filename=f"{Path(name).stem}_deobfuscated.lua"),
            content=f"Engine: `{engine}`"
        )
    except subprocess.TimeoutExpired:
        await status.edit(content=f"⏱️ Quá thời gian xử lý ({TIMEOUT}s), job đã bị dừng.")
    except Exception as exc:
        await status.edit(content=f"❌ Bot gặp lỗi: `{type(exc).__name__}: {exc}`")
    finally:
        shutil.rmtree(work, ignore_errors=True)


@deobf_cmd.error
async def deobf_error(ctx: commands.Context, error):
    if isinstance(error, commands.CommandOnCooldown):
        await ctx.reply(f"Chờ {error.retry_after:.1f}s rồi thử lại.")
    else:
        await ctx.reply(f"❌ `{type(error).__name__}: {error}`")


def main():
    token = os.getenv("DISCORD_BOT_TOKEN")
    if not token:
        raise SystemExit("Thiếu biến môi trường DISCORD_BOT_TOKEN")
    if not CLI.is_file():
        raise SystemExit(f"Không tìm thấy deobfuscator: {CLI}")
    bot.run(token)


if __name__ == "__main__":
    main()
