# Discord Deobfuscator Bot - Termux

## Cài đặt

```bash
pkg update
pkg install python clang cmake ninja make git unzip -y
pip install -r requirements-bot.txt
```

Build Luau runtime của project nếu chưa có:

```bash
cd Deobfuscator/deobf
python build_luau.py --portable
```

## Token bot

Không ghi token vào `discord_bot.py`.

```bash
export DISCORD_BOT_TOKEN='YOUR_BOT_TOKEN'
```

Chạy:

```bash
cd /path/to/luraph-v15-v14.x-deobfuscator-main
./run_bot.sh
```

## Discord

Bật **Message Content Intent** cho bot trong Discord Developer Portal.

Dùng:

- `.help` - xem lệnh
- `.d` + file `.lua`/`.luau` - auto detect Luraph v14.7/v14.8/v14.9
- `.d 14.7` + file - ép engine v14.7
- `.d 14.8` + file - ép engine v14.8
- `.d 14.9` + file - ép engine v14.9

Bot chạy `Deobfuscator/deobf/cli.py` trực tiếp, nên output Discord dùng đúng engine trong project này.
