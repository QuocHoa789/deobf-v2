#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = __dirname;
const V15 = path.join(ROOT, 'v15', 'deob.js');
const V14 = path.join(ROOT, 'v14x', 'cli.py');

function inputArg(argv) {
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a || a.startsWith('-')) {
      if (a === '-o' || a === '--output' || a === '--engine' || a === '--timeout' || a === '--budget' || a === '--max-runs' || a === '--devirt-rounds' || a === '--executor' || a === '--input-text' || a === '--luau') i++;
      continue;
    }
    return a;
  }
  return null;
}

function readSource(file) {
  if (!file || !fs.existsSync(file)) return '';
  try { return fs.readFileSync(file, 'latin1'); } catch { return ''; }
}

function detect(source) {
  const head = source.slice(0, 4096);
  const banner = /This file was protected using Luraph Obfuscator v(\d+)(?:\.(\d+))?/i.exec(head);
  if (banner) {
    const major = banner[1];
    const minor = banner[2] || '';
    if (major === '15') return { engine: 'v15', label: 'Luraph v15', confidence: 1.0 };
    if (major === '14' && ['7','8','9'].includes(minor)) return { engine: `v14.${minor}`, label: `Luraph v14.${minor}`, confidence: 1.0 };
    if (major === '14') return { engine: 'v14', label: 'Luraph v14.x', confidence: 0.8 };
  }

  // Headerless V14 fingerprints used by the bundled V14 engines.
  const h20k = source.trimStart().slice(0, 20000);
  if (/^local init = \(function\(\.\.\./.test(h20k) && /return\(\{/.test(h20k)) {
    return { engine: 'v14.8', label: 'Luraph v14.8 (headerless)', confidence: 0.8 };
  }
  if (/^return\(function\(\)/.test(h20k) && /loadstring/.test(h20k.slice(0, 4000))) {
    return { engine: 'v14.7', label: 'Luraph v14.x (headerless)', confidence: 0.75 };
  }
  if (/^return\(\{/.test(h20k) && /(?:bit32|loadstring)/.test(source.slice(0, 100000))) {
    return { engine: 'v14.8', label: 'Luraph v14.x (headerless)', confidence: 0.7 };
  }

  // Headerless V15 fingerprints from the original V15 detector.
  const vmShape = /\[\d+\]=(?:bit32|buffer|string|table|math)\.\w+/.test(h20k);
  if (/^return setmetatable\(\{/.test(h20k) && (vmShape || source.slice(0, 200000).includes('LPH'))) {
    return { engine: 'v15', label: 'Luraph v15 (headerless)', confidence: 0.8 };
  }
  return { engine: null, label: 'unknown', confidence: 0.0 };
}

function pythonCommand() {
  return process.env.PYTHON_BIN || 'python3';
}

function run(command, args, cwd) {
  const r = spawnSync(command, args, {
    cwd,
    stdio: 'inherit',
    env: { ...process.env, PYTHONUNBUFFERED: '1' }
  });
  if (r.error) {
    console.error(`[!] failed to start ${command}: ${r.error.message}`);
    return 1;
  }
  return r.status == null ? 1 : r.status;
}

function main() {
  const argv = process.argv.slice(2);
  const input = inputArg(argv);
  const source = readSource(input);
  const detected = detect(source);

  if (argv.includes('--detect')) {
    console.log(`${path.basename(input || 'input.lua')}\t${detected.engine || 'unknown'}\t${detected.confidence.toFixed(2)}\t${detected.label}`);
    return detected.engine ? 0 : 1;
  }

  if (!detected.engine) {
    console.error('[!] Could not detect Luraph V14.x/V15 from this file.');
    console.error('[!] Supported: Luraph v14.7, v14.8, v14.9 and v15.');
    return 2;
  }

  console.error(`[*] router: ${detected.label} -> ${detected.engine === 'v15' ? 'V15 engine' : 'V14.x engine'}`);

  if (detected.engine === 'v15') {
    if (!fs.existsSync(V15)) {
      console.error(`[!] V15 source is missing: ${V15}`);
      return 1;
    }
    return run(process.execPath, [V15, ...argv], ROOT);
  }

  if (!fs.existsSync(V14)) {
    console.error(`[!] V14 CLI is missing: ${V14}`);
    return 1;
  }
  // Pass the exact detected V14 engine so ambiguous headerless V14 files don't
  // silently jump to another version.
  const forwarded = argv.slice();
  if (!forwarded.includes('--engine')) forwarded.push('--engine', detected.engine);
  let status = run(pythonCommand(), [V14, ...forwarded], path.dirname(V14));
  if (status === 127 && !process.env.PYTHON_BIN) status = run('python', [V14, ...forwarded], path.dirname(V14));
  return status;
}

process.exitCode = main();
