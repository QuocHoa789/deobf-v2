#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -d bot/node_modules/discord.js ]; then
  echo "[!] Discord dependency not installed. Run ./install-termux.sh first."
  exit 1
fi
if [ ! -x v15/bin/luau ]; then
  echo "[!] v15/bin/luau is missing. Run ./install-termux.sh and complete the native Luau setup."
  exit 1
fi
if [ ! -x v14x/bin/luau-ast ]; then
  echo "[!] v14x/bin/luau-ast is missing. V14.x jobs may fail until native luau-ast is installed."
fi
if [ ! -x v15/bin/luau-ast ]; then
  echo "[!] v15/bin/luau-ast is missing. V15 jobs may fail until native luau-ast is installed."
fi
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
export DEOB_STACK_MB="${DEOB_STACK_MB:-64}"
exec node --max-old-space-size=1024 bot/index.js
