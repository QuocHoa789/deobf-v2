# Engine layout

- `v15/` contains the Luraph V15 engine source and its runtime/bin assets.
- `v14x/` contains the Luraph V14.7/V14.8/V14.9 engines and their shared runtime/bin assets.
- Root `deob.js` is the auto-router used by the Discord bot.
- The router detects Luraph V14.x vs V15 and calls only the matching engine tree.
