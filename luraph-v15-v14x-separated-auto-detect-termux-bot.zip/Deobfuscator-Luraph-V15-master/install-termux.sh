#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
V15="$ROOT/v15"
V14="$ROOT/v14x"

echo "[1/5] Installing Termux packages..."
pkg update -y
pkg install -y nodejs python git clang cmake make unzip

echo "[2/5] Installing Discord bot dependency..."
cd "$ROOT/bot"
npm install --omit=dev
cd "$ROOT"

echo "[3/5] Checking native Luau runtime..."
for engine in "$V15" "$V14"; do
  mkdir -p "$engine/bin"
  if [ -x "$HOME/luau/build/luau" ]; then
    cp "$HOME/luau/build/luau" "$engine/bin/luau"
    chmod +x "$engine/bin/luau"
    echo "[OK] $engine/bin/luau <- $HOME/luau/build/luau"
  elif [ -x "$engine/bin/luau" ]; then
    echo "[OK] $engine/bin/luau exists"
  else
    echo "[!] Native Luau missing for $engine"
  fi

done

echo "[4/5] Checking native luau-ast..."
for engine in "$V15" "$V14"; do
  if [ -x "$engine/bin/luau-ast" ]; then
    echo "[OK] $engine/bin/luau-ast exists"
  elif [ -x "$HOME/luau/build/luau-ast" ]; then
    cp "$HOME/luau/build/luau-ast" "$engine/bin/luau-ast"
    chmod +x "$engine/bin/luau-ast"
    echo "[OK] $engine/bin/luau-ast <- $HOME/luau/build/luau-ast"
  else
    cat >&2 <<EOF
[!] Native luau-ast missing for $engine.
    Build it on Termux with:
      cd ~/luau
      cmake --build build --target Luau.Ast.CLI -j2
EOF
  fi
done

echo "[5/5] Permissions..."
chmod +x "$ROOT/start-bot.sh" 2>/dev/null || true
chmod +x "$V15/deob.js" "$V15/bin/luau" "$V15/bin/luau-ast" 2>/dev/null || true
chmod +x "$V14/cli.py" "$V14/luau-ast" "$V14/bin/luau" "$V14/bin/luau-ast" 2>/dev/null || true

echo
echo "=== INSTALL COMPLETE ==="
echo "Start bot with: ./start-bot.sh"
echo "Bot prompts for DISCORD_TOKEN when no token environment variable is set."
