#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
cd bot
npm install
exec node index.js
